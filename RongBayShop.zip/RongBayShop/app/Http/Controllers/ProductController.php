<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\FileController;
use App\Models\ProductModel;
class ProductController extends Controller
{
    //
    public function create(Request $request)
    {
        $file = new FileController();
        $fileId= $file->saveFile($request)->id;
        $product = new ProductModel($request->all());
        $product->fileId = $fileId;
        return $product ->save();
    }
    public function getAll(Request $request){
        $list = new ProductModel();
        return $list->with('file')
                    ->with('category_product')
                    ->get();
    }

}
