<?php

namespace App\Http\Controllers;
use App\Models\FileModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
class FileController extends Controller
{
   public function saveFile(REQUEST $request)
   {
        $file = new FileModel();
        return $file::create($request->all());

   }
   public function getFile(REQUEST $request)
   {
        return $url = Storage::url('1611391851.png');
    }

}
