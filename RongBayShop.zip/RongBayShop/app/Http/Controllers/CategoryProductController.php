<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CategoryProduct;
class CategoryProductController extends Controller
{
    public function create(Request $request)
    {
       return  CategoryProduct::create($request->all());
    }
    public function getAll(Request $request)
    {
       return  CategoryProduct::all();
    }
    public function update(Request $request)
    {
       if(isset($request->id)){
            $category_cd = CategoryProduct::find($request->id);
            if(isset($category_cd)){
                $category_cd->update($request->all());
                return $request->all();
            }
       }
    }
    public function delete(Request $request)
    {
        if(isset($request->id)){
            $category_cd = CategoryProduct::find($request->id);
            if(isset($category_cd)){
                $category_cd->delete();
            }
        }
    }
}
